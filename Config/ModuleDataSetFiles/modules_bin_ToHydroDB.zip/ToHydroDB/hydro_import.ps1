﻿## Declare global variables#######
## Sql server connection variables##########
$SQLServer = "sql-core";
$SQLDBName = "hydrotest";
$user = 'hyuser'
$pass = 'hyuser'

#### Get input file for bulk insert, Diagnostic file and field terminator for bulk insert from command line################
$File=$args[0];
$Diag_file=$args[1];
$field_terminator=$args[2];


#### Declare xml template and file name #####
#### Get the path where the script lives and create the diagnostic file in a directory named Logs ###
#### within the script directory ###########
$ScriptPath = $MyInvocation.MyCommand.Path
$ScriptDir  = Split-Path -Parent $ScriptPath
$xmlpath = $ScriptDir + "\Logs\"
if((Test-Path $xmlpath) -eq 0)
{
  mkdir $xmlpath;
}
$xmlfile = $xmlpath + $Diag_file + ".xml";


##### If the below path is changed to one of the FEWSservers path, make sure ##########
##### to comment the code to copy the import file to this hydstra path ###############
##### and provide the appropriate import file name along with the path for BULK insert query #########
$File_path = "\\cbrnas01\hydstra\hyd\dat\ptmp\ROWS_HYDROEXP\";

#### Delete existing diagnostic file###############
If(Test-Path $xmlfile) 
{
  Remove-Item $xmlfile
}
[System.XML.XMLDocument]$xmlDoc=New-Object System.XML.XMLDocument
[System.XML.XMLElement]$xmlroot=$xmlDoc.CreateElement("Diag") 
$xmlDoc.appendChild($xmlroot) 
$xmlroot.SetAttribute("xmlns","http://www.wldelft.nl/fews/PI") 
$xmlroot.SetAttribute("version","1.2") 
$decl = $xmlDoc.CreateXmlDeclaration("1.0","UTF-8","no");
$xmlDoc.InsertBefore($decl,$xmlroot)

### Check if the import file and Diagnostic file is passed as an argument #################
### If not create a default Diagnostic file (Diag.xml) accordingly ##################
if ($File -eq $null -or $Diag_file -eq $null -or $field_terminator -eq $null)
{
   $xml_default = $xmlpath + "Diag.xml"
   $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
   $newLine.SetAttribute("description","3 Arguments Expected: Importdata file, Diagnostic file, Field terminator for bulk insert");
   $newLine.SetAttribute("level","1");
   $xmlDoc.Save($xml_default);
   exit;
}
## if the input file exists copy it to hydstra path for import
else
{
  if (Test-Path $File)
  {
    $filename = split-path $File -Leaf  ##get filename of importfile
    $importfile = $File_path + $filename ##Assign import file path to hydstra
    Copy-Item -Path $File -Destination $importfile
  }
  else
  {
    $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
    $newLine.SetAttribute("description","Import Data file is not found");
    $newLine.SetAttribute("level","1");
    $xmlDoc.Save($xmlfile);
    exit;
  }
}

########## Declare sql queries ###########################33
$DEL_STAGING = "Delete from DAILY_DATA_STAGING_TABLE";
$BULK_INSERT = "BULK INSERT hydrotest.dbo.daily_data_staging_table FROM '$importfile'
WITH (FIELDTERMINATOR = '$field_terminator' , ROWTERMINATOR = '\n', CHECK_CONSTRAINTS, MAXERRORS=0)";
$DEL_ERR_MEAS = "Delete from ERR`$_DAILY_MEASUREMENTS";
$COUNT_ERR_MEAS = "Select count(*) from ERR`$_DAILY_MEASUREMENTS";
$RUN_SP = "sp_ImportHydroDaily_ROWS";
$SEL_ERR_MEAS = "SELECT SITEID, MEASURANDID, ERROR, COUNT(ERROR) As Cnt from ERR`$_DAILY_MEASUREMENTS GROUP BY SITEID, MEASURANDID, ERROR";
$COUNT_STAGING = "select count(*) from DAILY_DATA_STAGING_TABLE";
$import_stage=1;
$SqlQuery = @($DEL_STAGING, $COUNT_STAGING,  $BULK_INSERT, $COUNT_STAGING, $DEL_ERR_MEAS, $COUNT_ERR_MEAS, $RUN_SP, $DEL_STAGING, $COUNT_ERR_MEAS, $COUNT_STAGING);

### Other variables used in script for error handling ################
$Exception = "";
$Err_Measurements = "";

####### Sql connection and query execution ###########################
try
{             
    $SqlConnection = New-Object System.Data.SqlClient.SqlConnection;
    $SqlConnection.ConnectionString = "Server = $SQLServer; Database = $SQLDBName; uid=$user; pwd=$pass" 
    $SqlCmd = New-Object System.Data.SqlClient.SqlCommand
    $SqlCmd.Connection = $SqlConnection

    foreach ($Query in $SqlQuery)
    {
      write-host "Query is $Query"
      $SqlCmd.CommandText = $Query
      $SqlCmd.CommandType = [System.Data.CommandType]'Text'; 
      $SqlConnection.Open()
      ## Using ExecuteScalar() method for executing select count(*) statements to get the rows returned ####
      if($Query -Match "select")
      {
             $rowcount = $SqlCmd.ExecuteScalar()
             write-host "Number of rows returned by the query is: $rowcount"
             ##### Error handling after executing the stored proc - Check for errors in daily measurements table#####
             if ($rowcount -gt 0 -and $import_stage -eq 9)
             {
               $SqlCmd.CommandText = $SEL_ERR_MEAS
               
               $SqlAdapter = New-Object System.Data.SqlClient.SqlDataAdapter
               $SqlAdapter.SelectCommand = $SqlCmd
               $DataSet = New-Object System.Data.DataSet
               $SqlAdapter.Fill($DataSet);

               $Errors = $DataSet.Tables[0]
               
               ## Write the Validation Errors to the diagnostic File if any ########################################
               $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
               $newLine.SetAttribute("description","Error Executing stored procedure");
               $newLine.SetAttribute("level","1");
               $Errors | ForEach-Object {
                    $site = $_.SITEID
                    $measurand = $_.MEASURANDID
                    $err =  $_.ERROR
                    $err_count = $_.Cnt
                    $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
                    $newLine.SetAttribute("description","$site, $measurand,$err, $err_count rows affected")
                    $newLine.SetAttribute("level","1")
               }
               $Err_Measurements = 1;
             }          
      }
      #### Using ExecuteNonQuery() to run other queries (Bulkinsert, run storedproc and delete statements ########
      else
      {        
         if ($import_stage -eq 7) ## To execute the stored procedure and get the ErrorMsg
         {
            $SqlCmd.CommandType = [System.Data.CommandType]'StoredProcedure'; 
            $outParameter = new-object System.Data.SqlClient.SqlParameter;
            $outParameter.ParameterName = "@ErrorMsg";
            $outParameter.Direction = [System.Data.ParameterDirection]'Output';
            $outparameter.size = 4000;
            $SqlCmd.Parameters.Add($outParameter) >> $null; 
            $result = $SqlCmd.ExecuteNonQuery(); 
            $ErrorMsg = $SqlCmd.Parameters["@ErrorMsg"].Value;
            if($ErrorMsg)
            {
                $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
                $newLine.SetAttribute("description","$ErrorMsg")
                $newLine.SetAttribute("level","1")
            }
         }
         else
         {
           
             $value = $SqlCmd.ExecuteNonQuery()
             Write-Host "value is $value"
         }
      }
      $SqlConnection.Close()
      #### Import stage set for error handling at different stages of import ##############
      $import_stage=$import_stage+1;
    }
}
######### catch any sql exceptions in query executions ##########################################
catch [System.Exception]
{
    $Exception = $_.Exception.Message
    write-host $Exception
    ### catch the exception adn write it to the Diagnostic file ##############################
    $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
    $newLine.SetAttribute("description","Query Executed: $Query");
    $newLine.SetAttribute("level","1");
    $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
    $newLine.SetAttribute("description",$Exception);
    ### Set the 
    if ($import_stage -eq 8)
    {
        $newLine.SetAttribute("level","2")
    }
    else
    {
       $newLine.SetAttribute("level","1")
    }
    
}

##### If no exception is raised and there are no errors in err_daily_measurements then write #########3
####### successful data import into the Diagnostic File ##############3
if($Exception -eq "" -and $Err_Measurements -eq "" -and $ErrorMsg -eq "")
{
    $newLine = $xmlDoc.Diag.AppendChild($xmldoc.CreateElement("line"));
    $newLine.SetAttribute("description","Data successfully loaded into the hydro database")
    $newLine.SetAttribute("level","3")
}

$xmlDoc.Save($xmlfile);